import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import os
from youngblood_photodetector import UNIT_REGISTRY as ureg

import data_acquisition.app
from ..daq_utils import get_local_maximum, STRINGIFIED_UNITS

TIME_UNITS = (ureg.s, ureg.ms, ureg.us)
INTENSITY_UNITS = (ureg.watt, ureg.mwatt, ureg.uwatt, ureg.nwatt, ureg.pwatt)

layout = html.Div(
    id='local-maximum',
    children=[
        html.H2('Locate Local Maximum'),
        html.Div(
            children=[
                'Interval: ',
                dcc.Input(
                    id='local-maximum-start-interval-value',
                    type='number',
                    placeholder=None,
                    style={'height': '25px', 'width': '50px'}
                ),
                dcc.Dropdown(
                    id='local-maximum-start-interval-units',
                    options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                    value=STRINGIFIED_UNITS[ureg.s],
                    style={'height': '15px', 'width': '50px'}
                ),
                html.Div(
                    'to',
                    style={'margin': '5px'}
                ),
                dcc.Input(
                    id='local-maximum-end-interval-value',
                    type='number',
                    placeholder=None,
                    style={'height': '25px', 'width': '50px'}
                ),
                dcc.Dropdown(
                    id='local-maximum-end-interval-units',
                    options=[{'label': STRINGIFIED_UNITS[unit], 'value': STRINGIFIED_UNITS[unit]} for unit in TIME_UNITS],
                    value=STRINGIFIED_UNITS[ureg.s],
                    style={'height': '15px', 'width': '50px'}
                ),
            ],
            style={'display':'flex', 'margin-top':'15px','margin-bottom':'15px'}
        ),
        html.Div(id='local-maximum-result')
    ]
)

@data_acquisition.app.app.callback(
    Output('local-maximum-result','children'),
    [Input('local-maximum-start-interval-value','value'),
    Input('local-maximum-start-interval-units','value'),
    Input('local-maximum-end-interval-value','value'),
    Input('local-maximum-end-interval-units','value'),
    Input('sample-plot-time-unit','value'),
    Input('sample-plot-intensity-unit','value')]
)
def update_maximum(start_time_value, start_time_units, end_time_value, end_time_units, display_time_unit, display_intensity_unit):
    result = 'Cannot locate maximum over specified interval'
    if data_acquisition.app.device is not None and len(list(data_acquisition.app.device.current_samples)) > 0:
        max_sample = get_local_maximum(
            sample_data=data_acquisition.app.device.current_samples,
            start_time=start_time_value * ureg.parse_units(start_time_units),
            end_time=end_time_value * ureg.parse_units(end_time_units)
        )
        time_unit = ureg.parse_units(display_time_unit)
        intensity_unit = ureg.parse_units(display_intensity_unit)
        result = 'Maximum sample over interval: t = {0} {1}, I = {2} {3}'.format(
            str(max_sample[0].to(time_unit).magnitude),
            display_time_unit,
            str(max_sample[1].to(intensity_unit).magnitude),
            display_intensity_unit
        )
    return result