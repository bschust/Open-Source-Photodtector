import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
from youngblood_photodetector import UNIT_REGISTRY as ureg

import data_acquisition.app

layout = html.Div(children=[
    dcc.Graph(
        id='responsivity-chart',
        figure={
            'data': [
                {'x': [], 'y': [], 'type': 'scatter'},
                {'x': [], 'y': [], 'type': 'scatter'}
            ],
            'layout':{
                'title': 'Device Responsivity',
                'xaxis': {
                    'title': 'Wavelength (nm)'
                },
                'yaxis': {
                    'title': 'Responsivity (A/W)'
                }
            }
        },
        style={'height': '450px'}
    ),
    html.Div(
        children=[
            "Input Wavelength (nm):\t",
            dcc.Input(
                id='responsivity-wavelength-input',
                placeholder="Enter a value...",
                type="number",
                value=0
            )
        ],
        style={'display': 'inline'}
    ),
    html.Div(
        children=[
            "Reponsivity (A/W):",
            html.Span(id='calculated-responsivity')
        ]
    )
])

@data_acquisition.app.app.callback(
    [Output('responsivity-chart','figure'),
    Output('calculated-responsivity','children')],
    [Input('device-status','children'),
    Input('responsivity-wavelength-input','value')],
    [State('responsivity-chart','figure')]
)
def plot_responsivity(device_status,responsivity_input,figure):
    calculated_responsivity = 'Device not found'
    if data_acquisition.app.device is not None and data_acquisition.app.device.responsivity is not None:
        # split the list of tuples into two lists for our coordinate values
        wavelength_data,responsivity_data = zip(*list(data_acquisition.app.device.responsivity))

        # strip the units from these values so they can be plotted
        wavelength_data = [data.magnitude for data in wavelength_data]
        responsivity_data = [data.magnitude for data in responsivity_data]

        # update the figure to include this data in the plot
        figure['data'][0]['x'] = wavelength_data
        figure['data'][0]['y'] = responsivity_data

        # attempt to get the interpolated wavelength at the user's specified value
        responsivity_nm = responsivity_input * ureg.nm
        if data_acquisition.app.device.responsivity.is_valid_wavelength(responsivity_nm):
            responsivity_at = data_acquisition.app.device.responsivity.at(responsivity_nm)
            figure['data'][1]['x'] = responsivity_nm.magnitude
            figure['data'][1]['y'] = responsivity_at.magnitude
            calculated_responsivity = str(responsivity_at.magnitude)
        else:
            calculated_responsivity = 'Invalid wavelength entered'
            figure['data'][1]['x'] = []
            figure['data'][1]['y'] = []


    return figure,calculated_responsivity