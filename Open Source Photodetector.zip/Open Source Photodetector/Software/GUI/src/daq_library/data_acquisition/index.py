import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_table
from dash.dependencies import Input, Output, State
from decimal import Decimal
import plotly.graph_objs as go
from pyfladesk import init_gui

from youngblood_photodetector import Photodetector

from data_acquisition.app import app
from data_acquisition.components import (
    device_select,
    export_csv,
    gain_select,
    local_maximum,
    responsivity_plot,
    sampling_plot,
    wavelength_input
)

app.layout = html.Div(children=[

    # hidden div used as a target for output for callbacks which modify the device
    # but don't modify any DOM elements (bit of a hack)
    html.Div(id='hidden-div',style={'display': 'none'},children=None),

    device_select.layout,

    dcc.Tabs(
        id='index-plot-tabs',
        value='index-sampling-tab',
        children=[
            dcc.Tab(label='Sampling Plot', value='index-sampling-tab'),
            dcc.Tab(label='Responsivity Plot', value='index-responsivity-tab'),
        ]
    ),

    html.Div(
        id='index-responsivity-content',
        style={'display': 'none'},
        children=[
            responsivity_plot.layout
        ]
    ),

    html.Div(
        id='index-sampling-content',
        style={'display': 'inline'},
        children=[
            sampling_plot.layout,
            local_maximum.layout,
            export_csv.layout,
        ]
    )
])

@app.callback(
    [Output('index-responsivity-content','style'),
    Output('index-sampling-content','style')],
    [Input('index-plot-tabs','value')],
    [State('index-responsivity-content','style'),
    State('index-sampling-content','style')]
)
def show_tab(tab,responsivity_style,sampling_style):
    if tab == 'index-responsivity-tab':
        responsivity_style['display'] = 'inline'
        sampling_style['display'] = 'none'
    elif tab == 'index-sampling-tab':
        responsivity_style['display'] = 'none'
        sampling_style['display'] = 'inline'
    
    return responsivity_style,sampling_style



if __name__ == "__main__":
    init_gui(app.server,window_title='Photodetector DAQ', width=1200, height=900)