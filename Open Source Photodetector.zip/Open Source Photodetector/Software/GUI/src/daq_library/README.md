# Photodetector DAQ

This package contains code for a graphic user interface used to control sampling for the photodetector device designed for the University of Pittsburgh's Youngblood Photonics Lab.

The photodetector and GUI were designed as part of a Spring 2020 Senior Design course.

Run the GUI by installing the data_acquisition library and then executing in command prompt `python -m data_acquisition.index`